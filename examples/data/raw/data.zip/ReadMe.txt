
**************************************************************************
              ReadMe file for Campus Safety and Security 2013
                                          
              Prepared by IT Innovative Solutions - DEC 14, 2013 
**************************************************************************


Crime2013EXCEL.zip contains the following files:

        Noncampusarrest101112.xls -- noncampus arrest data for year 2010, year 2011 and 2012
        Noncampuscrime101112.xls -- noncampus criminal offenses data for year 2010, year 2011 and 2012
        Noncampusdiscipline101112.xls -- noncampus disciplinary actions data for year 2010, year 2011 and 2012
        Noncampushate101112.xlsx -- noncampus hate crimes data for year 2010, year 2011 and 2012
        Oncampusarrest101112.xls -- on-campus arrest data for year 2010, year 2011 and 2012
        Oncampuscrime101112.xls -- on-campus criminal offenses data for year 2010, year 2011 and 2012
        Oncampusdiscipline101112.xls -- on-campus disciplinary actions data for year 2010, year 2011 and 2012
        Oncampushate101112.xlsx -- on-campus hate crimes data for year 2010, year 2011 and 2012
        Publicpropertyarrest101112.xls -- public property arrest data for year 2010, year 2011 and 2012
        Publicpropertycrime101112.xls -- public property criminal offenses data for year 2010, year 2011 and 2012
        Publicpropertydiscipline101112.xls -- public property disciplinary actions data for year 2010, year 2011 and 2012
        Publicpropertyhate101112.xlsx -- public propert hate crimes data for year 2010, year 2011 and 2012
        Reportedarrest101112.xls -- reported arrest data for year 2010, year 2011 and 2012
        Reportedcrime101112.xls -- reported criminal offenses data for year 2010, year 2011 and 2012
        Reporteddiscipline101112.xls -- reported disciplinary actions data for year 2010, year 2011 and 2012
        Reportedhate101112.xlsx -- reported hate crimes data for year 2010, year 2011 and 2012
        Residencehallarrest101112.xls -- residence hall arrest data for year 2010, year 2011 and 2012
        Residencehallcrime101112.xls -- residence hall criminal offenses data for year 2010, year 2011 and 2012
        Residencehalldiscipline101112.xls -- residence hall disciplinary actions data for year 2010, year 2011 and 2012
        Residencehallhate101112.xlsx -- residence hall hate crimes data for year 2010, year 2011 and 2012
	Residencehallfire10.xls -- residence hall fire data for year 2010
        Residencehallfire11.xls -- residence hall fire data for year 2011
	Residencehallfire12.xls -- residence hall fire data for year 2012
        
      

Data Dictionaries for Each Excel File
        Noncampusarrest101112_Doc.doc
        Noncampuscrime101112_Doc.doc
        Noncampusdiscipline101112_Doc.doc
        Noncampushate101112_Doc.doc
        Oncampusarrest101112_Doc.doc
        Oncampuscrime101112_Doc.doc
        Oncampusdiscipline101112_Doc.doc
        Oncampushate101112_Doc.doc
        Publicpropertyarrest101112_Doc.doc
        Publicpropertycrime101112_Doc.doc
        Publicpropertydiscipline101112_Doc.doc
        Publicpropertyhate101112_Doc.doc
        Reportedarrest101112_Doc.doc
        Reportedcrime101112_Doc.doc
        Reporteddiscipline101112_Doc.doc
        Reportedhate101112_Doc.doc
        Residencehallarrest101112_Doc.doc
        Residencehallcrime101112_Doc.doc
        Residencehalldiscipline0708_Doc.doc
	Residencehallhate101112_Doc.doc
        Residencehallfire10_Doc.doc
        Residencehallfire11_Doc.doc
	Residencehallfire12_Doc.doc
        
   
   __________________________________________________________________________ 

